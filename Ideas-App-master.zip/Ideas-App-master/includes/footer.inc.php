 <!-- Footer -->

	    <footer class="page-footer font-small">

	      <!-- Copyright -->

	      <div class="footer-copyright text-center py-3">© 2020 Copyright:
			<a href="#"> E-Web Development Team 3</a>
	      </div>

	      <!-- Copyright -->
            
            <!-- Admin Link -->
            

	    </footer>

	    <!-- Footer -->

	</body>

</html>
