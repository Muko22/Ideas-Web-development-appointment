IMPORTANT: THE WEBSITE HAS TO BE RUN USING AN INTERNET CONNECTION IN ORDER TO SEND EMAIL NOTIFICATIONS AND GET THE
COMPLETE INTERFACE LAYOUT.

Open the setup.php file in your web browser to create the database and add the data.                                            


						** Default User Credentials **

Administrator   -> email: admin201196@ideas.com
                   password: Admin1234

QA Manager      -> email: qamanager201196@ideas.com
                   password: QA1234

QA Coordinators -> email: josephwamulume201196@ideas.com
                   password: Joseph1234

                   email: kondwaningombo201196@ideas.com
                   password: Kondwani1234

                   email: thandizulu201196@ideas.com
                   password: Thandizani1234

                   email: paulchibamba201196@ideas.com
                   password: Paul1234

                   email: johndoe201196@ideas.com
                   password: Joseph1234

                   email: janedoe201196@ideas.com
                   password: Jane1234

* No page can be accessed a user is not logged in
* Only a QA Manager can access the QA Manager Dashboard
* Only an Administrator can access the Administrator Dashboard


